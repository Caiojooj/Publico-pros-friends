aint doing this shit correctly
